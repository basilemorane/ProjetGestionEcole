package Controleur;
import Vue.RootWindow;
import Vue.Window;

public class Test {

        public static void main(String[] s){
           // Window window = new Window();
            // Udpatebdd upd = new Udpatebdd();

            RootWindow rootWindow = new RootWindow();
            rootWindow.setVisible(true);
        }
    }
